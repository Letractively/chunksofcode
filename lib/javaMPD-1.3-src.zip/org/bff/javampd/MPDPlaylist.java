/*
 * MPDPlaylist.java
 *
 * Created on September 30, 2005, 5:51 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package org.bff.javampd;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import org.bff.javampd.events.PlaylistChangeEvent;
import org.bff.javampd.events.PlaylistChangeListener;
import org.bff.javampd.exception.MPDConnectionException;
import org.bff.javampd.exception.MPDPlaylistException;
import org.bff.javampd.exception.MPDResponseException;

/**
 * MPDPlaylist represents a playlist controller to a MPD server.  To obtain
 * an instance of the class you must use the <code>getMPDPlaylist</code> method from
 * the {@link MPD} connection class.  This class does not have a public constructor
 * (singleton model) so the object must be obtained from the connection object.
 * @author Bill Findeisen
 * @version 1.0
 */
public class MPDPlaylist {
    private MPD             mpd         = null;
    private Properties      prop        = null;
    private int             oldVersion  = -1;
    private int             version     = -1;
    private List<MPDSong>   songList    = null;
    
    private List<PlaylistChangeListener> listeners = new ArrayList<PlaylistChangeListener>();
    
    private static final String MPDPROPADD      = "MPD_PLAYLIST_ADD";
    private static final String MPDPROPCLEAR    = "MPD_PLAYLIST_CLEAR";
    private static final String MPDPROPCURRSONG = "MPD_PLAYLIST_CURRSONG";
    private static final String MPDPROPDELETE   = "MPD_PLAYLIST_DELETE";
    private static final String MPDPROPCHANGES  = "MPD_PLAYLIST_CHANGES";
    private static final String MPDPROPID       = "MPD_PLAYLIST_LIST_ID";
    private static final String MPDPROPINFO     = "MPD_PLAYLIST_LIST";
    private static final String MPDPROPLOAD     = "MPD_PLAYLIST_LOAD";
    private static final String MPDPROPMOVE     = "MPD_PLAYLIST_MOVE";
    private static final String MPDPROPMOVEID   = "MPD_PLAYLIST_MOVE_ID";
    private static final String MPDPROPREMOVE   = "MPD_PLAYLIST_REMOVE";
    private static final String MPDPROPREMOVEID = "MPD_PLAYLIST_REMOVE_ID";
    private static final String MPDPROPSAVE     = "MPD_PLAYLIST_SAVE";
    private static final String MPDPROPSHUFFLE  = "MPD_PLAYLIST_SHUFFLE";
    private static final String MPDPROPSWAP     = "MPD_PLAYLIST_SWAP";
    private static final String MPDPROPSWAPID   = "MPD_PLAYLIST_SWAP_ID";
    
    /**
     * Creates a new instance of MPDPlaylist
     * @param mpd the MPD connection
     */
    MPDPlaylist(MPD mpd) {
        this.mpd = mpd;
        this.prop   = mpd.getMPDProperties();
        try {
            songList = new ArrayList<MPDSong>(listSongs());
        } catch(Exception e) {
            songList = new ArrayList<MPDSong>();
        }
    }
    
    /**
     * Adds a {@link PlaylistChangeListener} to this object to receive
     * {@link PlaylistChangeEvent}s.
     * @param pcl the PlaylistChangeListener to add
     */
    public synchronized void addPlaylistChangeListener(PlaylistChangeListener pcl) {
        listeners.add(pcl);
    }
    
    /**
     * Removes a {@link PlaylistChangeListener} from this object.
     * @param pcl the PlaylistChangeListener to remove
     */
    public synchronized void removePlaylistStatusChangedListener(PlaylistChangeListener pcl) {
        listeners.remove(pcl);
    }
    
    /**
     * Sends the appropriate {@link PlaylistChangeEvent} to all registered
     * {@link PlaylistChangeListener}.
     * @param id the event id to send
     */
    protected synchronized void firePlaylistChangeEvent(int id) {
        PlaylistChangeEvent pce = new PlaylistChangeEvent(this, id);
        
        for(PlaylistChangeListener pcl : listeners) {
            pcl.playlistChanged(pce);
        }
    }
    
    /**
     * Loads the songs in the given playlist to the current playlist.  The playlist
     * name can be givin with or without the .m3u extension.
     * @param playlistName the playlist name
     * @throws org.bff.javampd.exception.MPDPlaylistException if the MPD responded with an error
     * @throws org.bff.javampd.exception.MPDConnectionException if there is a problem sending the command
     */
    public void loadPlaylist(String playlistName) throws MPDConnectionException, MPDPlaylistException {
        if(playlistName.endsWith(".m3u")) {
            playlistName = playlistName.substring(playlistName.length()-4);
        }
        
        MPDCommand command = new MPDCommand(prop.getProperty(MPDPROPLOAD),playlistName);
        
        try {
            mpd.sendMPDCommand(command);
        } catch(MPDResponseException re) {
            throw new MPDPlaylistException(re.getMessage(), re.getCommand());
        } catch(Exception e) {
            throw new MPDPlaylistException(e.getMessage());
        }
        
        setSongList(listSongs());
        setVersion(getPlaylistVersion());
    }
    
    /**
     * Adds a {@link MPDSong} to the playlist.
     * @param song the song to add
     * @throws org.bff.javampd.exception.MPDPlaylistException if the MPD responded with an error
     * @throws org.bff.javampd.exception.MPDConnectionException if there is a problem sending the command
     * @return true if the song was added, false otherwise
     */
    public boolean addSong(MPDSong song) throws MPDConnectionException, MPDPlaylistException {
        List<String> response = null;
        MPDCommand command = new MPDCommand(prop.getProperty(MPDPROPADD), song.getFile());
        try {
            response = new ArrayList<String>(mpd.sendMPDCommand(command));
        } catch(MPDResponseException re) {
            throw new MPDPlaylistException(re.getMessage(), re.getCommand());
        } catch(Exception e) {
            throw new MPDPlaylistException(e.getMessage());
        }
        
        int oldCount = songList.size();
        updatePlaylist();
        
        if(oldCount < songList.size()) {
            firePlaylistChangeEvent(PlaylistChangeEvent.SONG_ADDED);
            return(true);
        } else {
            return(false);
        }
    }
    
    /**
     * Adds a <CODE>List</CODE> of {@link MPDSong}s to the playlist.
     * @return true if the songs are added successfully; false otherwise
     * @param songList the list of songs to add
     * @throws org.bff.javampd.exception.MPDPlaylistException if the MPD responded with an error
     * @throws org.bff.javampd.exception.MPDConnectionException if there is a problem sending the command
     */
    public boolean addSongs(List<MPDSong> songList) throws MPDConnectionException, MPDPlaylistException {
        List<MPDCommand> commandList = new ArrayList();
        for(MPDSong song : songList) {
            commandList.add(new MPDCommand(prop.getProperty(MPDPROPADD), song.getFile()));
        }
        try {
            return(mpd.sendMPDCommands(commandList));
        } catch(MPDResponseException re) {
            throw new MPDPlaylistException(re.getMessage(), re.getCommand());
        } catch(Exception e) {
            throw new MPDPlaylistException(e.getMessage());
        }
    }
    
    /**
     * Adds a directory of songs to the playlist.
     * @param dir the directory to add
     * @throws org.bff.javampd.exception.MPDPlaylistException if the MPD responded with an error
     * @throws org.bff.javampd.exception.MPDConnectionException if there is a problem sending the command
     */
    public void addDirectory(String dir) throws MPDConnectionException, MPDPlaylistException {
        MPDCommand command = new MPDCommand(prop.getProperty(MPDPROPADD), dir);
        try {
            mpd.sendMPDCommand(command);
        } catch(MPDResponseException re) {
            throw new MPDPlaylistException(re.getMessage(), re.getCommand());
        } catch(Exception e) {
            throw new MPDPlaylistException(e.getMessage());
        }
        updatePlaylist();
    }
    
    /**
     * Removes a {@link MPDSong} from the playlist.
     * @return true if the song is removed; false otherwise
     * @param song the song to remove
     * @throws org.bff.javampd.exception.MPDPlaylistException if the MPD responded with an error
     * @throws org.bff.javampd.exception.MPDConnectionException if there is a problem sending the command
     */
    public boolean removeSong(MPDSong song) throws MPDConnectionException, MPDPlaylistException {
        List<String> response = null;
        MPDCommand   command  = null;
        
        if(song.getId() > -1) {
            command = new MPDCommand(prop.getProperty(MPDPROPREMOVEID), Integer.toString(song.getId()));
            
        } else if(song.getPosition() > -1) {
            command = new MPDCommand(prop.getProperty(MPDPROPREMOVE), Integer.toString(song.getPosition()));
        }
        try {
            response = new ArrayList<String>(mpd.sendMPDCommand(command));
        } catch(MPDResponseException re) {
            throw new MPDPlaylistException(re.getMessage(), re.getCommand());
        } catch(Exception e) {
            throw new MPDPlaylistException(e.getMessage());
        }
        
        int oldCount = songList.size();
        updatePlaylist();
        
        if(oldCount > songList.size()) {
            firePlaylistChangeEvent(PlaylistChangeEvent.SONG_DELETED);
            return(true);
        } else {
            return(false);
        }
    }
    
    /**
     * Returns the current song.
     * @return the current song
     * @throws org.bff.javampd.exception.MPDPlaylistException if the MPD responded with an error
     * @throws org.bff.javampd.exception.MPDConnectionException if there is a problem sending the command
     */
    public MPDSong getCurrentSong() throws MPDConnectionException, MPDPlaylistException {
        MPDCommand command      = new MPDCommand(prop.getProperty(MPDPROPCURRSONG));
        List<String> response   = null;
        
        try {
            response = new ArrayList<String>(mpd.sendMPDCommand(command));
        } catch(MPDResponseException re) {
            throw new MPDPlaylistException(re.getMessage(), re.getCommand());
        } catch(Exception e) {
            throw new MPDPlaylistException(e.getMessage());
        }
        
        List<MPDSong> songList = new ArrayList<MPDSong>(mpd.convertResponseToSong(response));
        
        if(songList.size()==0) {
            return(null);
        } else {
            return(songList.get(0));
        }
    }
    
    /**
     * Removes all songs from the playlist.
     * @throws org.bff.javampd.exception.MPDPlaylistException if the MPD responded with an error
     * @throws org.bff.javampd.exception.MPDConnectionException if there is a problem sending the command
     * @return true if the playlist was cleared
     */
    public boolean clearPlaylist() throws MPDConnectionException, MPDPlaylistException {
        try {
            List<String> response =
                    new ArrayList<String>(mpd.sendMPDCommand(new MPDCommand(prop.getProperty(MPDPROPCLEAR))));
        } catch(MPDResponseException re) {
            throw new MPDPlaylistException(re.getMessage(), re.getCommand());
        } catch(Exception e) {
            throw new MPDPlaylistException(e.getMessage());
        }
        
        updatePlaylist();
        
        if(songList.size()==0) {
            firePlaylistChangeEvent(PlaylistChangeEvent.PLAYLIST_CLEARED);
            return(true);
        } else {
            return(false);
        }
    }
    
    /**
     * Deletes the playlist from the MPD server.
     * @param playlistName the playlist to delete
     * @throws org.bff.javampd.exception.MPDPlaylistException if the MPD responded with an error
     * @throws org.bff.javampd.exception.MPDConnectionException if there is a problem sending the command
     */
    public void deletePlaylist(String playlistName) throws MPDConnectionException, MPDPlaylistException {
        MPDCommand command =
                new MPDCommand(prop.getProperty(MPDPROPDELETE), playlistName);
        try {
            List<String> response =
                    new ArrayList<String>(mpd.sendMPDCommand(command));
        } catch(MPDResponseException re) {
            throw new MPDPlaylistException(re.getMessage(), re.getCommand());
        } catch(Exception e) {
            throw new MPDPlaylistException(e.getMessage());
        }
        firePlaylistChangeEvent(PlaylistChangeEvent.PLAYLIST_DELETED);
    }
    
    /**
     * Moves the desired song to the given position in the playlist.
     * @param song the song to move
     * @param to the position to move the song to
     * @throws org.bff.javampd.exception.MPDPlaylistException if the MPD responded with an error
     * @throws org.bff.javampd.exception.MPDConnectionException if there is a problem sending the command
     */
    public void move(MPDSong song, int to) throws MPDConnectionException, MPDPlaylistException {
        String[]     paramList  = new String[2];
        MPDCommand   command    = null;
        List<String> response   = null;
        
        paramList[1] = Integer.toString(to);
        if(song.getId() > -1) {
            paramList[0] = Integer.toString(song.getId());
            command = new MPDCommand(prop.getProperty(MPDPROPMOVEID),paramList);
        } else if(song.getPosition() > -1) {
            paramList[0] = Integer.toString(song.getPosition());
            command = new MPDCommand(prop.getProperty(MPDPROPMOVEID),paramList);
            
        }
        try {
            response = new ArrayList<String>(mpd.sendMPDCommand(command));
        } catch(MPDResponseException re) {
            throw new MPDPlaylistException(re.getMessage(), re.getCommand());
        } catch(Exception e) {
            throw new MPDPlaylistException(e.getMessage());
        }
        
        updatePlaylist();
    }
    
    /**
     * Shuffles the songs in the playlist.
     * @throws org.bff.javampd.exception.MPDPlaylistException if the MPD responded with an error
     * @throws org.bff.javampd.exception.MPDConnectionException if there is a problem sending the command
     */
    public void shuffle() throws MPDConnectionException, MPDPlaylistException {
        try {
            mpd.sendMPDCommand(new MPDCommand(prop.getProperty(MPDPROPSHUFFLE)));
        } catch(MPDResponseException re) {
            throw new MPDPlaylistException(re.getMessage(), re.getCommand());
        } catch(Exception e) {
            throw new MPDPlaylistException(e.getMessage());
        }
        
        updatePlaylist();
    }
    
    /**
     * Swaps the given two songs in the playlist.
     * @param song1 first song to swap
     * @param song2 second song to swap
     * @throws org.bff.javampd.exception.MPDPlaylistException if the MPD responded with an error
     * @throws org.bff.javampd.exception.MPDConnectionException if there is a problem sending the command
     */
    public void swap(MPDSong song1, MPDSong song2) throws MPDConnectionException, MPDPlaylistException {
        String[]     paramList  = new String[2];
        MPDCommand   command    = null;
        List<String> response   = null;

        if(song1.getId() > -1 && song2.getId() > -1) {
            paramList[0] = Integer.toString(song1.getId());
            paramList[1] = Integer.toString(song2.getId());
            command = new MPDCommand(prop.getProperty(MPDPROPSWAPID),paramList);
        } else if(song1.getPosition() > -1 && song2.getPosition() > -1) {
         
            paramList[0] = Integer.toString(song1.getPosition());
            paramList[1] = Integer.toString(song2.getPosition());
            command = new MPDCommand(prop.getProperty(MPDPROPSWAP),paramList);
        }

        try {
            response = new ArrayList<String>(mpd.sendMPDCommand(command));
        } catch(MPDResponseException re) {
            throw new MPDPlaylistException(re.getMessage(), re.getCommand());
        } catch(Exception e) {
            throw new MPDPlaylistException(e.getMessage());
        }
        updatePlaylist();
    }
    
    /**
     * Saves the current playlist as the passed playlist name.
     * @param playlistName the playlist name for the playlist
     * @return true if the playlist is saved; otherwise false
     * @throws org.bff.javampd.exception.MPDPlaylistException if the MPD responded with an error
     * @throws org.bff.javampd.exception.MPDConnectionException if there is a problem sending the command
     */
    public boolean savePlaylist(String playlistName) throws MPDConnectionException, MPDPlaylistException {
        if(playlistName!=null) {
            MPDCommand command = new MPDCommand(prop.getProperty(MPDPROPSAVE), playlistName);
            try {
                List<String> response = new ArrayList<String>(mpd.sendMPDCommand(command));
                firePlaylistChangeEvent(PlaylistChangeEvent.PLAYLIST_SAVED);
            } catch(MPDResponseException re) {
                throw new MPDPlaylistException(re.getMessage(), re.getCommand());
            } catch(Exception e) {
                throw new MPDPlaylistException(e.getMessage());
            }
            return(true);
        } else {
            throw new MPDPlaylistException("Playlist name hasn't been set!");
        }
    }
    
    private void updatePlaylist() throws MPDConnectionException, MPDPlaylistException {
        setSongList(listSongs());
        setVersion(getPlaylistVersion());
        
        if(getPlaylistVersion()!=oldVersion) {
            oldVersion = getVersion();
            firePlaylistChangeEvent(PlaylistChangeEvent.PLAYLIST_CHANGED);
        }
    }
    
    private int getPlaylistVersion() throws MPDConnectionException, MPDPlaylistException {
        //TODO playlist returning null
        try {
            return(Integer.parseInt(mpd.getStatus(MPD.StatusList.PLAYLIST)));
        } catch(MPDResponseException re) {
            throw new MPDPlaylistException(re.getMessage(), re.getCommand());
        } catch(Exception e) {
            throw new MPDPlaylistException(e.getMessage());
        }
    }
    
    /**
     * Returns the list of songs in the playlist.
     * @return the list of songs
     * @throws org.bff.javampd.exception.MPDConnectionException if there is a problem sending the command
     */
    private List<MPDSong> listSongs() throws MPDConnectionException, MPDPlaylistException {
        MPDCommand command      = new MPDCommand(prop.getProperty(MPDPROPINFO));
        List<String> response   = null;
        
        try {
            response = new ArrayList<String>(mpd.sendMPDCommand(command));
        } catch(MPDResponseException re) {
            throw new MPDPlaylistException(re.getMessage(), re.getCommand());
        } catch(Exception e) {
            throw new MPDPlaylistException(e.getMessage());
        }
        
        List<MPDSong> list = new ArrayList<MPDSong>(mpd.convertResponseToSong(response));
        return(list);
    }
    
    /**
     * Returns the playlist version.
     * @return the playlist version
     */
    public int getVersion() {
        return version;
    }
    
    /**
     * Sets the playlist version.
     * @param version
     */
    private void setVersion(int version) {
        this.version = version;
    }
    
    /**
     * Returns the list of songs in the playlist.
     * @return the song list
     */
    public List<MPDSong> getSongList() {
        return songList;
    }
    
    private void setSongList(List<MPDSong> songList) {
        this.songList = songList;
    }
    
    /**
     * Returns the string representation of this playlist.
     * @return the string representation
     */
    public String toString() {
        StringBuffer sb = new StringBuffer();
        sb.append("Version:"+getVersion()+"\n");
        sb.append("Song Count:"+getSongList().size());
        return(sb.toString());
    }
}
