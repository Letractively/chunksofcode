/*
 * MPDDatabase.java
 *
 * Created on September 28, 2005, 8:23 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package org.bff.javampd;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import org.bff.javampd.exception.MPDConnectionException;
import org.bff.javampd.exception.MPDDatabaseException;
import org.bff.javampd.exception.MPDResponseException;

/**
 * MPDDatabase represents a database controller to a MPD server.  To obtain
 * an instance of the class you must use the <code>getMPDDatabase</code> method from
 * the {@link MPD} connection class.  This class does not have a public constructor
 * (singleton model) so the object must be obtained from the connection object.
 * @author Bill Findeisen
 * @version 1.0
 */
public class MPDDatabase {
    private MPD mpd = null;
    private Properties prop     = null;
    
    //database properties contants
    private static final String MPDPROPFIND         = "MPD_DB_FIND";
    private static final String MPDPROPLIST         = "MPD_DB_LIST_TAG";
    private static final String MPDPROPLISTALL      = "MPD_DB_LIST_ALL";
    private static final String MPDPROPLISTALLINFO  = "MPD_DB_LIST_ALL_INFO";
    private static final String MPDPROPLISTINFO     = "MPD_DB_LIST_INFO";
    private static final String MPDPROPSEARCH       = "MPD_DB_SEARCH";
    private static final String MPDPROPLISTSONGS    = "MPD_DP_LIST_SONGS";
    
    private enum ListType {
        ALBUM("album"),
        ARTIST("artist"),
        GENRE("genre");

        private String type;
        
        ListType(String type) {
            this.type = type;
        }
        
        public String getType() {
            return(type);
        }
    }
    
    private enum FindType {
        ALBUM("album"),
        ARTIST("artist"),
        TITLE("title");
        
        private String type;
        
        FindType(String type) {
            this.type = type;
        }
        
        public String getType() {
            return(type);
        }
    }
    
    private enum SearchType {
        ALBUM("album"),
        ARTIST("artist"),
        TITLE("title"),
        FILENAME("filename");
        
        private String type;
        
        SearchType(String type) {
            this.type = type;
        }
        
        public String getType() {
            return(type);
        }
    }
    
    private enum ListInfoType {
        PLAYLIST("playlist:"),
        DIRECTORY("directory:");
        //FILE("file:");
        
        private String prefix;
        
        ListInfoType(String prefix) {
            this.prefix = prefix;
        }
        
        public String getPrefix() {
            return(prefix);
        }
    }
    
    /**
     * Class constructor
     * @param mpd a connection to a MPD
     */
    MPDDatabase(MPD mpd) {
        this.mpd    = mpd;
        this.prop   = mpd.getMPDProperties();
    }
    
    /**
     * Returns a <CODE>Collection</CODE> of <CODE>MPDSong</CODE>s for an artist.
     * Please note this only returns an exact match of artist.  To find a partial
     * match use {@link #searchArtist(String artist)}.
     * @param artist the artist to find
     * @return a <CODE>Collection</CODE> of <CODE>MPDSong</CODE>s
     * @throws org.bff.javampd.exception.MPDDatabaseException if the MPD responded with an error
     * @throws org.bff.javampd.exception.MPDConnectionException if there is a problem sending the command
     */
    public Collection<MPDSong> findArtist(String artist) throws MPDConnectionException, MPDDatabaseException {
        return(find(FindType.ARTIST, artist));
    }
    
    /**
     * Returns a <CODE>Collection</CODE> of <CODE>MPDSong</CODE>s for an artist.
     * Please note this only returns an exact match of album.  To find a partial
     * match use {@link #searchAlbum(String artist)}.
     * @return a <CODE>Collection</CODE> of <CODE>MPDSong</CODE>s
     * @param album the album to find
     * @throws org.bff.javampd.exception.MPDDatabaseException if the MPD responded with an error
     * @throws org.bff.javampd.exception.MPDConnectionException if there is a problem sending the command
     */
    public Collection<MPDSong> findAlbum(String album) throws MPDConnectionException, MPDDatabaseException {
        return(find(FindType.ALBUM, album));
    }
    
    /**
     * Returns a <CODE>Collection</CODE> of <CODE>MPDSong</CODE>s for an album by
     * a particulat artist. Please note this only returns an exact match of album
     * and artist.
     * @return a <CODE>Collection</CODE> of <CODE>MPDSong</CODE>s
     * @param artist the artist alcum belongs to
     * @param album the album to find
     * @throws org.bff.javampd.exception.MPDDatabaseException if the MPD responded with an error
     * @throws org.bff.javampd.exception.MPDConnectionException if there is a problem sending the command
     */
    public Collection<MPDSong> findAlbumByArtist(String artist, String album) throws MPDConnectionException, MPDDatabaseException {
        List<MPDSong> retList = new ArrayList<MPDSong>();
        
        List<MPDSong> songList = new ArrayList<MPDSong>(find(FindType.ALBUM, album));
        
        for(MPDSong song : songList) {
            if(song.getArtist().equals(artist)) {
                retList.add(song);
            }
        }
        
        return(retList);
    }
    
    /**
     * Returns a <CODE>Collection</CODE> of <CODE>MPDSong</CODE>s for a title.
     * Please note this only returns an exact match of title.  To find a partial
     * match use {@link #searchTitle(String title)}.
     * @return a <CODE>Collection</CODE> of <CODE>MPDSong</CODE>s
     * @param title the title to find
     * @throws org.bff.javampd.exception.MPDConnectionException if there is a problem sending the command
     * @throws org.bff.javampd.exception.MPDDatabaseException if the MPD responded with an error
     */
    public Collection<MPDSong> findTitle(String title) throws MPDConnectionException, MPDDatabaseException {
        return(find(FindType.TITLE, title));
    }
    
    /**
     * Returns a <CODE>Collection</CODE> of <CODE>Strings</CODE> of all
     * songs and directories from the mpd root.
     * @return a collection of Strings containing all files and dirs
     * @throws org.bff.javampd.exception.MPDDatabaseException if the MPD responded with an error
     * @throws org.bff.javampd.exception.MPDConnectionException if there is a problem sending the command
     */
    public Collection<String> listAllFiles() throws MPDConnectionException, MPDDatabaseException {
        MPDCommand command = new MPDCommand(prop.getProperty(MPDPROPLISTALL));
        
        try {
            return(mpd.sendMPDCommand(command));
        } catch(MPDResponseException re) {
            throw new MPDDatabaseException(re.getMessage(), re.getCommand());
        } catch(Exception e) {
            throw new MPDDatabaseException(e.getMessage());
        }
    }
    
    /**
     * Returns a <CODE>Collection</CODE> of <CODE>Strings</CODE> of all
     * songs and directories from the given path.
     * @return a collection of Strings containing all files and dirs
     * @param path the root of the list
     * @throws org.bff.javampd.exception.MPDDatabaseException if the MPD responded with an error
     * @throws org.bff.javampd.exception.MPDConnectionException if there is a problem sending the command
     */
    public Collection<String> listAllFiles(String path) throws MPDConnectionException, MPDDatabaseException {
        MPDCommand command = new MPDCommand(prop.getProperty(MPDPROPLISTALL), path);
        
        try {
            return(mpd.sendMPDCommand(command));
        } catch(MPDResponseException re) {
            throw new MPDDatabaseException(re.getMessage(), re.getCommand());
        } catch(Exception e) {
            throw new MPDDatabaseException(e.getMessage());
        }
    }
    
    /**
     * Returns a <CODE>Collection</CODE> of <CODE>Strings</CODE> of all
     * songs from the mpd root.
     * @return a collection of Strings containing all files and dirs
     * @throws org.bff.javampd.exception.MPDDatabaseException if the MPD responded with an error
     * @throws org.bff.javampd.exception.MPDConnectionException if there is a problem sending the command
     */
    public Collection<String> listAllSongFiles() throws MPDConnectionException, MPDDatabaseException {
        MPDCommand command      = new MPDCommand(prop.getProperty(MPDPROPLISTALL));
        List<String> fileList   = null;
        
        try {
            fileList = new ArrayList<String>(mpd.sendMPDCommand(command));
        } catch(MPDResponseException re) {
            throw new MPDDatabaseException(re.getMessage(), re.getCommand());
        } catch(Exception e) {
            throw new MPDDatabaseException(e.getMessage());
        }
        
        List<String> retList = new ArrayList<String>();
        
        for(String s : fileList) {
            if(s.startsWith(mpd.SONGPREFIXFILE)) {
                retList.add((s.substring(mpd.SONGPREFIXFILE.length())).trim());
            }
        }
        
        return(retList);
    }
    
    /**
     * Returns a <CODE>Collection</CODE> of <CODE>Strings</CODE> of all
     * songs from the given path.
     * @return a collection of Strings containing all files and dirs
     * @param path the root of the list
     * @throws org.bff.javampd.exception.MPDDatabaseException if the MPD responded with an error
     * @throws org.bff.javampd.exception.MPDConnectionException if there is a problem sending the command
     */
    public Collection<String> listAllSongFiles(String path) throws MPDConnectionException, MPDDatabaseException {
        MPDCommand command      = new MPDCommand(prop.getProperty(MPDPROPLISTALL), path);
        List<String> fileList   = null;
        
        try {
            fileList = new ArrayList<String>(mpd.sendMPDCommand(command));
        } catch(MPDResponseException re) {
            throw new MPDDatabaseException(re.getMessage(), re.getCommand());
        } catch(Exception e) {
            throw new MPDDatabaseException(e.getMessage());
        }
        
        List<String> retList = new ArrayList<String>();
        
        for(String s : fileList) {
            if(s.startsWith(MPD.SONGPREFIXFILE)) {
                retList.add((s.substring(MPD.SONGPREFIXFILE.length())).trim());
            }
        }
        return(retList);
    }
    
    /**
     * Returns a <CODE>Collection</CODE> of <CODE>MPDSong</CODE>s of all
     * songs from the mpd root.
     * @return a collection of Strings containing all files and dirs
     * @throws org.bff.javampd.exception.MPDDatabaseException if the MPD responded with an error
     * @throws org.bff.javampd.exception.MPDConnectionException if there is a problem sending the command
     */
    public Collection<MPDSong> listAllSongs() throws MPDConnectionException, MPDDatabaseException {
        MPDCommand command      = new MPDCommand(prop.getProperty(MPDPROPLISTALLINFO));
        List<String> songList   = null;
        
        try {
            songList = new ArrayList<String>(mpd.sendMPDCommand(command));
        } catch(MPDResponseException re) {
            throw new MPDDatabaseException(re.getMessage(), re.getCommand());
        } catch(Exception e) {
            throw new MPDDatabaseException(e.getMessage());
        }
        
        return(new ArrayList<MPDSong>(mpd.convertResponseToSong(songList)));
    }
    
    /**
     * Returns a <CODE>Collection</CODE> of <CODE>MPDSong</CODE>s of all
     * songs from the given path.
     * @return a collection of Strings containing all files and dirs
     * @param path the root of the list
     * @throws org.bff.javampd.exception.MPDDatabaseException if the MPD responded with an error
     * @throws org.bff.javampd.exception.MPDConnectionException if there is a problem sending the command
     */
    public Collection<MPDSong> listAllSongs(String path) throws MPDConnectionException, MPDDatabaseException {
        MPDCommand command      = new MPDCommand(prop.getProperty(MPDPROPLISTALLINFO), path);
        List<String> songList   = null;
        
        try {
            songList = new ArrayList<String>(mpd.sendMPDCommand(command));
        } catch(MPDResponseException re) {
            throw new MPDDatabaseException(re.getMessage(), re.getCommand());
        } catch(Exception e) {
            throw new MPDDatabaseException(e.getMessage());
        }
        
        return(new ArrayList<MPDSong>(mpd.convertResponseToSong(songList)));
    }
    
    /**
     * Returns a <CODE>Collection</CODE> of <CODE>MPDSong</CODE>s for an any
     * artist containing the parameter artist.
     * Please note this returns a partial match of an artist.  To find an
     * exact match use {@link #searchArtist(String artist)}.
     * @return a <CODE>Collection</CODE> of <CODE>MPDSong</CODE>s
     * @param artist the artist to match
     * @throws org.bff.javampd.exception.MPDDatabaseException if the MPD responded with an error
     * @throws org.bff.javampd.exception.MPDConnectionException if there is a problem sending the command
     */
    public Collection<MPDSong> searchArtist(String artist) throws MPDConnectionException, MPDDatabaseException {
        return(search(SearchType.ARTIST, artist));
    }
    
    /**
     * Returns a <CODE>Collection</CODE> of <CODE>MPDSong</CODE>s for an any
     * album containing the parameter album.
     * Please note this returns a partial match of an album.  To find an
     * exact match use {@link #searchAlbum(String album)}.
     * @return a <CODE>Collection</CODE> of <CODE>MPDSong</CODE>s
     * @param album the album to match
     * @throws org.bff.javampd.exception.MPDDatabaseException if the MPD responded with an error
     * @throws org.bff.javampd.exception.MPDConnectionException if there is a problem sending the command
     */
    public Collection<MPDSong> searchAlbum(String album) throws MPDConnectionException, MPDDatabaseException {
        return(search(SearchType.ALBUM, album));
    }
    
    /**
     * Returns a <CODE>Collection</CODE> of <CODE>MPDSong</CODE>s for an any
     * title containing the parameter title.
     * Please note this returns a partial match of a title.  To find an
     * exact match use {@link #searchTitle(String title)}.
     * @return a <CODE>Collection</CODE> of <CODE>MPDSong</CODE>s
     * @param title the title to match
     * @throws org.bff.javampd.exception.MPDDatabaseException if the MPD responded with an error
     * @throws org.bff.javampd.exception.MPDConnectionException if there is a problem sending the command
     */
    public Collection<MPDSong> searchTitle(String title) throws MPDConnectionException, MPDDatabaseException {
        return(search(SearchType.TITLE, title));
    }
    
    /**
     * Returns a <CODE>Collection</CODE> of <CODE>MPDSong</CODE>s for an any
     * file name containing the parameter filename.
     * @return a <CODE>Collection</CODE> of <CODE>MPDSong</CODE>s
     * @param fileName the file name to match
     * @throws org.bff.javampd.exception.MPDDatabaseException if the MPD responded with an error
     * @throws org.bff.javampd.exception.MPDConnectionException if there is a problem sending the command
     */
    public Collection<MPDSong> searchFileName(String fileName) throws MPDConnectionException, MPDDatabaseException {
        fileName = Utils.removeSlashes(fileName);
        return(search(SearchType.FILENAME, fileName));
    }
    
    /**
     * Returns a <CODE>Collection</CODE> of <CODE>Strings</CODE> of all
     * albums in the database.
     * @return a <CODE>Collection</CODE> of <CODE>Strings</CODE> containing the album names
     * @throws org.bff.javampd.exception.MPDDatabaseException if the MPD responded with an error
     * @throws org.bff.javampd.exception.MPDConnectionException if there is a problem sending the command
     */
    public Collection<String> listAllAlbums() throws MPDConnectionException, MPDDatabaseException {
        return(list(ListType.ALBUM, null));
    }
    
    /**
     * Returns a <CODE>Collection</CODE> of <CODE>Strings</CODE> of all
     * artists in the database.
     * @return a <CODE>Collection</CODE> of <CODE>Strings</CODE> containing the album names
     * @throws org.bff.javampd.exception.MPDDatabaseException if the MPD responded with an error
     * @throws org.bff.javampd.exception.MPDConnectionException if there is a problem sending the command
     */
    public Collection<String> listAllArtists() throws MPDConnectionException, MPDDatabaseException {
        return(list(ListType.ARTIST, null));
    }
    
    /**
     * Returns a <CODE>Collection</CODE> of <CODE>Strings</CODE> of all
     * genres in the database.
     * @return a <CODE>Collection</CODE> of <CODE>Strings</CODE> containing the genre names
     * @throws org.bff.javampd.exception.MPDDatabaseException if the MPD responded with an error
     * @throws org.bff.javampd.exception.MPDConnectionException if there is a problem sending the command
     */
    public Collection<String> listAllGenres() throws MPDConnectionException, MPDDatabaseException {
        return(list(ListType.GENRE, null));
    }

    /**
     * Returns a <CODE>Collection</CODE> of <CODE>Strings</CODE> of all
     * albums by a particular artist.
     * @return a <CODE>Collection</CODE> of <CODE>Strings</CODE> of all
     * albums
     * @param artist the artist to find albums
     * @throws org.bff.javampd.exception.MPDDatabaseException if the MPD responded with an error
     * @throws org.bff.javampd.exception.MPDConnectionException if there is aproblem sending the command
     */
    public Collection<String> listAlbumsByArtist(String artist) throws MPDConnectionException, MPDDatabaseException {
        List<String> list = new ArrayList<String>();
        //list.add(ListType.ARTIST.getType());
        list.add(artist);
        return(list(ListType.ALBUM, list));
    }
    
    private Collection<String> listInfo(ListInfoType type) throws MPDConnectionException, MPDDatabaseException {
        List<String> returnList = new ArrayList<String>();
        List<String> list       = null;
        MPDCommand command      = new MPDCommand(prop.getProperty(MPDPROPLISTINFO));
        
        try {
            list = new ArrayList<String>(mpd.sendMPDCommand(command));
        } catch(MPDResponseException re) {
            throw new MPDDatabaseException(re.getMessage(), re.getCommand());
        } catch(Exception e) {
            throw new MPDDatabaseException(e.getMessage());
        }
        
        for(String s : list) {
            if(s.startsWith(type.getPrefix())) {
                returnList.add(s.substring(type.getPrefix().length()).trim());
            }
        }
        return(returnList);
    }
    
    private Collection<String> listInfo(ListInfoType type, String directory) throws MPDConnectionException, MPDDatabaseException {
        List<String> returnList = new ArrayList<String>();
        List<String> list       = null;
        MPDCommand command      = new MPDCommand(prop.getProperty(MPDPROPLISTINFO), directory);
        
        try {
            list = new ArrayList<String>(mpd.sendMPDCommand(command));
        } catch(MPDResponseException re) {
            throw new MPDDatabaseException(re.getMessage(), re.getCommand());
        } catch(Exception e) {
            throw new MPDDatabaseException(e.getMessage());
        }
        
        for(String s : list) {
            if(s.startsWith(type.getPrefix())) {
                returnList.add(s.substring(type.getPrefix().length()).trim());
            }
        }
        
        return(returnList);
    }
    
    private Collection<String> list(ListType listType, List<String> params) throws MPDConnectionException, MPDDatabaseException {
        String[] paramList;
        int i = 0;
        
        try {
            paramList = new String[params.size()+1];
        } catch(NullPointerException npe) {
            paramList = new String[1];
        }
        
        paramList[i++] = listType.getType();
        
        if(params!=null) {
            for(String s : params)
                paramList[i++] = s;
        }
        
        MPDCommand command = new MPDCommand(prop.getProperty(MPDPROPLIST), paramList);
        List<String> responseList = null;
        
        try {
            responseList = new ArrayList<String>(mpd.sendMPDCommand(command));
        } catch(MPDResponseException re) {
            throw new MPDDatabaseException(re.getMessage(), re.getCommand());
        } catch(Exception e) {
            throw new MPDDatabaseException(e.getMessage());
        }
        
        List<String> retList = new ArrayList<String>();
        for(String s : responseList) {
            try {
                retList.add((s.split(":")[1]).trim());
            } catch(ArrayIndexOutOfBoundsException e) {
                System.out.println("String with array problem:"+s);
            }
        }
        return(retList);
    }
    
    private Collection<MPDSong> search(SearchType searchType, String param) throws MPDConnectionException, MPDDatabaseException {
        String[] paramList = null;
        
        if(param!=null) {
            paramList = new String[2];
            paramList[1] = param;
        } else {
            paramList = new String[1];
        }
        
        paramList[0]            = searchType.getType();
        MPDCommand command      = new MPDCommand(prop.getProperty(MPDPROPSEARCH), paramList);
        List<String> titleList  = null;
        
        try {
            titleList = new ArrayList<String>(mpd.sendMPDCommand(command));
        } catch(MPDResponseException re) {
            throw new MPDDatabaseException(re.getMessage(), re.getCommand());
        } catch(Exception e) {
            throw new MPDDatabaseException(e.getMessage());
        }
        
        return(mpd.convertResponseToSong(titleList));
    }
    
    private Collection<MPDSong> find(FindType findType, String param) throws MPDConnectionException, MPDDatabaseException {
        String[] paramList = null;
        
        if(param!=null) {
            paramList = new String[2];
            paramList[1] = param;
        } else {
            paramList = new String[1];
        }
        paramList[0]            = findType.getType();
        MPDCommand command      = new MPDCommand(prop.getProperty(MPDPROPFIND), paramList);
        List<String> titleList  = null;
        
        try {
            titleList = new ArrayList<String>(mpd.sendMPDCommand(command));
        } catch(MPDResponseException re) {
            throw new MPDDatabaseException(re.getMessage(), re.getCommand());
        } catch(Exception e) {
            throw new MPDDatabaseException(e.getMessage());
        }
        
        return(mpd.convertResponseToSong(titleList));
    }
    
    /**
     * Returns the total number of artists in the database.
     * @return the total number of artists
     * @throws org.bff.javampd.exception.MPDConnectionException if there is a problem sending the command
     * @throws org.bff.javampd.exception.MPDDatabaseException if the MPD responded with an error
     */
    public int getArtistCount() throws MPDConnectionException, MPDDatabaseException {
        try {
            return(Integer.parseInt(mpd.getServerStat(MPD.StatList.ARTISTS)));
        } catch(MPDResponseException re) {
            throw new MPDDatabaseException(re.getMessage(), re.getCommand());
        } catch(Exception e) {
            throw new MPDDatabaseException(e.getMessage());
        }
    }
    
    /**
     * Returns the total number of albums in the database.
     * @return the total number of albums
     * @throws org.bff.javampd.exception.MPDConnectionException if there is a problem sending the command
     * @throws org.bff.javampd.exception.MPDDatabaseException if the MPD responded with an error
     */
    public int getAlbumCount() throws MPDConnectionException, MPDDatabaseException {
        try {
            return(Integer.parseInt(mpd.getServerStat(MPD.StatList.ALBUMS)));
        } catch(MPDResponseException re) {
            throw new MPDDatabaseException(re.getMessage(), re.getCommand());
        } catch(Exception e) {
            throw new MPDDatabaseException(e.getMessage());
        }
    }
    
    /**
     * Returns the total number of songs in the database.
     * @return the total number of songs
     * @throws org.bff.javampd.exception.MPDConnectionException if there is a problem sending the command
     * @throws org.bff.javampd.exception.MPDDatabaseException if the MPD responded with an error
     */
    public int getSongCount() throws MPDConnectionException, MPDDatabaseException {
        try {
            return(Integer.parseInt(mpd.getServerStat(MPD.StatList.SONGS)));
        } catch(MPDResponseException re) {
            throw new MPDDatabaseException(re.getMessage(), re.getCommand());
        } catch(Exception e) {
            throw new MPDDatabaseException(e.getMessage());
        }
    }
    
    /**
     * Returns the sum of all song times in database.
     * @return the sum of all song times
     * @throws org.bff.javampd.exception.MPDConnectionException if there is a problem sending the command
     * @throws org.bff.javampd.exception.MPDDatabaseException if the MPD responded with an error
     */
    public long getDbPlayTime() throws MPDConnectionException, MPDDatabaseException {
        try {
            return(Long.parseLong(mpd.getServerStat(MPD.StatList.DBPLAYTIME)));
        } catch(MPDResponseException re) {
            throw new MPDDatabaseException(re.getMessage(), re.getCommand());
        } catch(Exception e) {
            throw new MPDDatabaseException(e.getMessage());
        }
    }
    
    /**
     * Returns the last database update in UNIX time.
     * @return the last database update in UNIX time
     * @throws org.bff.javampd.exception.MPDConnectionException if there is a problem sending the command
     * @throws org.bff.javampd.exception.MPDDatabaseException if the MPD responded with an error
     */
    public long getLastUpdateTime() throws MPDConnectionException, MPDDatabaseException {
        try {
            return(Long.parseLong(mpd.getServerStat(MPD.StatList.DBUPDATE)));
        } catch(MPDResponseException re) {
            throw new MPDDatabaseException(re.getMessage(), re.getCommand());
        } catch(Exception e) {
            throw new MPDDatabaseException(e.getMessage());
        }
    }
    
    /**
     * Returns the mpd this database class is using.
     * @return the mpd connection
     */
    public MPD getMpd() {
        return mpd;
    }
    
    /**
     * Set the mpd connection this class is using.
     * @param mpd the mpd to use
     */
    public void setMpd(MPD mpd) {
        this.mpd = mpd;
    }
    
    /**
     * Returns a list of all available playlist names on the server.
     * @return a list of playlist names
     * @throws org.bff.javampd.exception.MPDDatabaseException if the MPD responded with an error
     * @throws org.bff.javampd.exception.MPDConnectionException if there is a problem sending the command
     */
    public Collection<String> listPlaylists() throws MPDConnectionException, MPDDatabaseException {
        try {
            return(listInfo(ListInfoType.PLAYLIST));
        } catch(MPDResponseException re) {
            throw new MPDDatabaseException(re.getMessage(), re.getCommand());
        } catch(Exception e) {
            throw new MPDDatabaseException(e.getMessage());
        }
    }
    
    public Collection<MPDSong> listPlaylistSongs(String playlistName) throws MPDConnectionException, MPDDatabaseException {
        MPDCommand command      = new MPDCommand(prop.getProperty(MPDPROPLISTSONGS), playlistName);
        List<String> response   = null;
        List<MPDSong> songList = null;
        try {
            response = new ArrayList<String>(mpd.sendMPDCommand(command));
            songList = new ArrayList<MPDSong>();
            for(String s : response) {
                songList.add(new ArrayList<MPDSong>(searchFileName(s.substring(MPD.SONGPREFIXFILE.length()).trim())).get(0));
            }
        } catch(MPDResponseException re) {
            throw new MPDDatabaseException(re.getMessage(), re.getCommand());
        } catch(Exception e) {
            throw new MPDDatabaseException(e.getMessage());
        }
        
        return(songList);
    }
    
}
