/*
 * MPDSong.java
 *
 * Created on September 27, 2005, 10:39 AM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package org.bff.javampd;

/**
 * MPDSong represents a song in the MPD database that can be inserted into
 * a playlist.
 * @author Bill Findeisen
 * @version 1.0
 */
public class MPDSong {
    
    private String  title       = null;
    private String  artist      = null;
    private String  album       = null;
    private String  file        = null;
    private String  genre       = null;
    private String  comment     = null;
    private String  year        = null;
    private int     length      = 0;
    private int     track       = 0;
    private int     position    = -1;
    private int     id          = -1;
    
    /** Creates a new instance of MPDSong */
    public MPDSong() {
    }
    
    /**
     * Returns the name of the song.
     * @return the name of the song.
     */
    public String getTitle() {
        return title;
    }
    
    /**
     * Sets the name of the song.
     * @param title the name of the song
     */
    public void setTitle(String title) {
        this.title = title;
    }
    
    /**
     * Returns the name of the artist.
     * @return the name of the artist
     */
    public String getArtist() {
        return artist;
    }
    
    /**
     * Sets the name of the artist.
     * @param artist the name of the artist
     */
    public void setArtist(String artist) {
        this.artist = artist;
    }
    
    /**
     * Returns the name of the album.
     * @return the name of the album
     */
    public String getAlbum() {
        return album;
    }
    
    /**
     * Sets the name of the album.
     * @param album the name of the album
     */
    public void setAlbum(String album) {
        this.album = album;
    }
    
    /**
     * Returns the path of the song without a leading or trailing slash.
     * @return the path of the song
     */
    public String getFile() {
        return file;
    }
    
    /**
     * Sets the path of the song.
     * Any leading or trailing slashes will be removed.
     * @param path the path of the song
     */
    public void setFile(String path) {
        this.file = path;
    }
    
    /**
     * Returns the length of the song in seconds.
     * @return the length of the song
     */
    public int getLength() {
        return length;
    }
    
    /**
     * Sets the length of the song.
     * @param length the length of the song in seconds
     */
    public void setLength(int length) {
        this.length = length;
    }
    
    /**
     * Returns the track number of the song.
     * @return the track number
     */
    public int getTrack() {
        return track;
    }
    
    /**
     * Sets the track number of the song
     * @param track the track number of the song
     */
    public void setTrack(int track) {
        this.track = track;
    }
    
    /**
     * Returns the genre of the song.
     * @return the genre of the song
     */
    public String getGenre() {
        return genre;
    }
    
    /**
     * Sets the genre of the song
     * @param genre the genre of the song
     */
    public void setGenre(String genre) {
        this.genre = genre;
    }
    
    /**
     * Returns the comment tag of the song.
     * @return the comment tag of the song
     */
    public String getComment() {
        return comment;
    }
    
    /**
     * Sets the comment tag of the song
     * @param comment the comment tag of the song
     */
    public void setComment(String comment) {
        this.comment = comment;
    }
    
    /**
     * Returns the year of the song.
     * @return the year of the song
     */
    public String getYear() {
        return year;
    }
    
    /**
     * Sets the year of the song
     * @param year the year of the song
     */
    public void setYear(String year) {
        this.year = year;
    }
    
    /**
     * Returns the string representation of this MPDSong.
     * @return the string representation
     */
    public String toString() {
        StringBuffer sb = new StringBuffer();
        sb.append("File:"+getFile()+"\n");
        sb.append("Title:"+getTitle()+"\n");
        sb.append("Artist:"+getArtist()+"\n");
        sb.append("Album:"+getAlbum()+"\n");
        sb.append("Track:"+getTrack()+"\n");
        sb.append("Year:"+getYear()+"\n");
        sb.append("Genre:"+getGenre()+"\n");
        sb.append("Comment:"+getComment()+"\n");
        sb.append("Length:"+getLength()+"\n");
        sb.append("Pos:"+getPosition()+"\n");
        sb.append("SongId:"+getId()+"\n");
        
        return(sb.toString());
    }
    
    /**
     * Returns the position of the song in the playlist. Returns
     * a -1 if the song is not in the playlist.
     * @return the position in the playlist
     */
    public int getPosition() {
        return position;
    }
    
    /**
     * Returns the playlist song id for the song. Returns
     * a -1 if the song is not in the playlist.
     * @return song id of the song
     */
    public int getId() {
        return id;
    }
    
    /**
     * Sets the playlist position for a song.
     * @param position the playlist position
     */
    public void setPosition(int position) {
        this.position = position;
    }
    
    /**
     * Sets the playlist song id for this MPDSong.
     * @param id the playlist song id
     */
    public void setId(int id) {
        this.id = id;
    }
    
    
    /**
     * Compares this MPDSong to the specified object.  The result is true if and only
     * if the argument is not null and is a MPDSong that has the same file path.
     * @param object the object to compare to
     * @return true if the paths are equal; false otherwise
     */
    public boolean equals(Object object) {
        if(this==object) {
            return(true);
        }
        
        if((object == null) || (object.getClass() != this.getClass())){
            return false;
        }
        
        MPDSong song = (MPDSong)object;
        if(this.getFile().equals(song.getFile())) {
            return(true);
        } else {
            return(false);
        }
    }
    
    /**
     * Returns the hash code for this object.
     * @return the hash code
     */
    public int hashCode() {
        int hash = 7;
        hash = 31 * hash + (int)getLength();
        hash = 31 * hash + (null == getTitle() ? 0 : getTitle().hashCode());
        return(hash);
    }
    
}
