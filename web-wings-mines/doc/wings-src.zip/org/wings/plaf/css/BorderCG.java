// (c) copyright 2006 by eXXcellent solutions, Ulm. Author: bschmid

package org.wings.plaf.css;

import org.wings.io.Device;
import org.wings.SComponent;
import org.wings.border.*;
import org.wings.style.*;

import java.io.IOException;

/** This is not a 'real' CG class but a class collection rendering code for variois borders. */
public class BorderCG {

    public void writeComponentBorderPrefix(final Device device, final SComponent component) throws IOException {
    }

    public void writeComponentBorderSufix(final Device device, final SComponent component) throws IOException {
    }
}
