/*
 * Copyright (c) 2005 Your Corporation. All Rights Reserved.
 */
package org.wings.plaf;



public interface PageScrollerCG extends ComponentCG {
}


