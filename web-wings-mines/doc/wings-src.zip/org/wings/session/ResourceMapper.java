package org.wings.session;

import org.wings.Resource;

public interface ResourceMapper
{
    Resource mapResource(String url);
}
