package org.wingx.table;

/**
 * @author leon
 */
public interface XTableClickListener {

    public void clickOccured(int row, int column);
    
}
