package org.wingx.plaf;

/**
 *
 *  * @author <a href="mailto:e.habicht@thiesen.com">Erik Habicht</a>
 */
public interface DivisionCG extends org.wings.plaf.ContainerCG {
}
