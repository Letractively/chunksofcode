package org.wingx.tree;

/**
 * Created by IntelliJ IDEA.
 * User: hengels
 * Date: Aug 4, 2006
 * Time: 1:00:47 PM
 * To change this template use File | Settings | File Templates.
 */
public interface LazyNode
{
    void initialize();
}
